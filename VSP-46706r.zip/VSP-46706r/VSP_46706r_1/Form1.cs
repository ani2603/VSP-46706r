﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSP_46706r_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            displayText.Text = txtBoxUserName.Text;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
           
        }

        private void txtBoxUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void AppExit(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
