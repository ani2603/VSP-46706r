﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSP_46706r_MyProject
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

       
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            //Get the checked part type and store it in variable
            string typeOfPart;
            if (radioButtonSuspension.Checked) typeOfPart = radioButtonSuspension.Text;
            else if (radioButtonEngine.Checked) typeOfPart = radioButtonEngine.Text;
            else if (radioButtonTransmition.Checked) typeOfPart = radioButtonTransmition.Text;
            else if (radioButtonService.Checked) typeOfPart = radioButtonService.Text;
            else if (radioButtonBody.Checked) typeOfPart = radioButtonBody.Text;
            else typeOfPart = radioButtonOther.Text;
            //Add a row with all the data
            dataGridView1.Rows.Add(typeOfPart, textBoxName.Text, Convert.ToInt32(textBoxPrice.Text), textBoxKm.Text, dateTimePicker1.Value);

            calculateTotals();
            //Prepare for next part
            textBoxKm.Text = "";
            textBoxName.Text = "";
            textBoxPrice.Text = "";

            tabControl1.SelectTab("tabPage2");
        }

        //Calculate totals and display them
        private void calculateTotals()
        {
            suspensionTotal.Text = Convert.ToString(calculateTypeTotal("Suspension")) + "$";
            engineTotal.Text = Convert.ToString(calculateTypeTotal("Engine")) + "$";
            transmitionTotal.Text = Convert.ToString(calculateTypeTotal("Transmition")) + "$";
            serviceTotal.Text = Convert.ToString(calculateTypeTotal("Service")) + "$";
            bodyTotal.Text = Convert.ToString(calculateTypeTotal("Body kit")) + "$";
            otherTotal.Text = Convert.ToString(calculateTypeTotal("Other")) + "$";
            total.Text = Convert.ToString(calculateTotal()) + "$";
        }
        //Calculate total for specific value type
        private int calculateTypeTotal(string value)
        {
            int sum = 0;
            for(int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (Convert.ToString(dataGridView1.Rows[i].Cells[0].Value) == value)
                {
                    sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[2].Value);
                }
                    
            }
            return sum;
        }
        //Calculate total prise of all value types
        private int calculateTotal()
        {
            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[2].Value);
            }
            return sum;
        }
        //Prevent user to entry chars in to Price and KM textbox field
        private void textBoxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if(!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }

        private void textBoxKm_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }
        //Disable add button if any of name or price textboxes are empty
        private void textBoxPrice_TextChanged(object sender, EventArgs e)
        {
            if (textBoxPrice.Text != "" && textBoxName.Text != "")
            {
                buttonAdd.Enabled = true;
            }
            else
            {
                buttonAdd.Enabled = false;
            }
        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {
            if (textBoxPrice.Text != "" && textBoxName.Text != "")
            {
                buttonAdd.Enabled = true;
            }
            else
            {
                buttonAdd.Enabled = false;
            }
        }
        //Delete a row that is selected
        private void buttonDellete_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow item in dataGridView1.SelectedRows)
            {
                dataGridView1.Rows.RemoveAt(item.Index);
            }
            calculateTotals();
        }
    }
}
