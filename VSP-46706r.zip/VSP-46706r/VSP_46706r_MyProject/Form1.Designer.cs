﻿namespace VSP_46706r_MyProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.groupBoxType = new System.Windows.Forms.GroupBox();
            this.radioButtonOther = new System.Windows.Forms.RadioButton();
            this.radioButtonBody = new System.Windows.Forms.RadioButton();
            this.radioButtonService = new System.Windows.Forms.RadioButton();
            this.radioButtonTransmition = new System.Windows.Forms.RadioButton();
            this.radioButtonEngine = new System.Windows.Forms.RadioButton();
            this.radioButtonSuspension = new System.Windows.Forms.RadioButton();
            this.textBoxKm = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonDellete = new System.Windows.Forms.Button();
            this.total = new System.Windows.Forms.Label();
            this.otherTotal = new System.Windows.Forms.Label();
            this.bodyTotal = new System.Windows.Forms.Label();
            this.serviceTotal = new System.Windows.Forms.Label();
            this.transmitionTotal = new System.Windows.Forms.Label();
            this.suspensionTotal = new System.Windows.Forms.Label();
            this.engineTotal = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.km = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBoxType.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(555, 244);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.TabStop = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.buttonAdd);
            this.tabPage1.Controls.Add(this.groupBoxType);
            this.tabPage1.Controls.Add(this.textBoxKm);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.textBoxPrice);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.textBoxName);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(547, 218);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Add part";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(504, 51);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(11, 13);
            this.label13.TabIndex = 5;
            this.label13.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(426, 81);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(11, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(404, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 24);
            this.label11.TabIndex = 5;
            this.label11.Text = "$";
            // 
            // buttonAdd
            // 
            this.buttonAdd.Enabled = false;
            this.buttonAdd.Location = new System.Drawing.Point(325, 160);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(112, 39);
            this.buttonAdd.TabIndex = 4;
            this.buttonAdd.Text = "Add";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // groupBoxType
            // 
            this.groupBoxType.Controls.Add(this.radioButtonOther);
            this.groupBoxType.Controls.Add(this.radioButtonBody);
            this.groupBoxType.Controls.Add(this.radioButtonService);
            this.groupBoxType.Controls.Add(this.radioButtonTransmition);
            this.groupBoxType.Controls.Add(this.radioButtonEngine);
            this.groupBoxType.Controls.Add(this.radioButtonSuspension);
            this.groupBoxType.Location = new System.Drawing.Point(8, 41);
            this.groupBoxType.Name = "groupBoxType";
            this.groupBoxType.Size = new System.Drawing.Size(200, 161);
            this.groupBoxType.TabIndex = 3;
            this.groupBoxType.TabStop = false;
            this.groupBoxType.Text = "Type of part";
            // 
            // radioButtonOther
            // 
            this.radioButtonOther.AutoSize = true;
            this.radioButtonOther.Checked = true;
            this.radioButtonOther.Location = new System.Drawing.Point(3, 138);
            this.radioButtonOther.Name = "radioButtonOther";
            this.radioButtonOther.Size = new System.Drawing.Size(51, 17);
            this.radioButtonOther.TabIndex = 0;
            this.radioButtonOther.TabStop = true;
            this.radioButtonOther.Text = "Other";
            this.radioButtonOther.UseVisualStyleBackColor = true;
            // 
            // radioButtonBody
            // 
            this.radioButtonBody.AutoSize = true;
            this.radioButtonBody.Location = new System.Drawing.Point(3, 117);
            this.radioButtonBody.Name = "radioButtonBody";
            this.radioButtonBody.Size = new System.Drawing.Size(63, 17);
            this.radioButtonBody.TabIndex = 0;
            this.radioButtonBody.Text = "Body kit";
            this.radioButtonBody.UseVisualStyleBackColor = true;
            // 
            // radioButtonService
            // 
            this.radioButtonService.AutoSize = true;
            this.radioButtonService.Location = new System.Drawing.Point(3, 94);
            this.radioButtonService.Name = "radioButtonService";
            this.radioButtonService.Size = new System.Drawing.Size(61, 17);
            this.radioButtonService.TabIndex = 0;
            this.radioButtonService.Text = "Service";
            this.radioButtonService.UseVisualStyleBackColor = true;
            // 
            // radioButtonTransmition
            // 
            this.radioButtonTransmition.AutoSize = true;
            this.radioButtonTransmition.Location = new System.Drawing.Point(3, 71);
            this.radioButtonTransmition.Name = "radioButtonTransmition";
            this.radioButtonTransmition.Size = new System.Drawing.Size(79, 17);
            this.radioButtonTransmition.TabIndex = 0;
            this.radioButtonTransmition.Text = "Transmition";
            this.radioButtonTransmition.UseVisualStyleBackColor = true;
            // 
            // radioButtonEngine
            // 
            this.radioButtonEngine.AutoSize = true;
            this.radioButtonEngine.Location = new System.Drawing.Point(3, 47);
            this.radioButtonEngine.Name = "radioButtonEngine";
            this.radioButtonEngine.Size = new System.Drawing.Size(58, 17);
            this.radioButtonEngine.TabIndex = 0;
            this.radioButtonEngine.Text = "Engine";
            this.radioButtonEngine.UseVisualStyleBackColor = true;
            // 
            // radioButtonSuspension
            // 
            this.radioButtonSuspension.AutoSize = true;
            this.radioButtonSuspension.Location = new System.Drawing.Point(3, 24);
            this.radioButtonSuspension.Name = "radioButtonSuspension";
            this.radioButtonSuspension.Size = new System.Drawing.Size(80, 17);
            this.radioButtonSuspension.TabIndex = 0;
            this.radioButtonSuspension.Text = "Suspension";
            this.radioButtonSuspension.UseVisualStyleBackColor = true;
            // 
            // textBoxKm
            // 
            this.textBoxKm.Location = new System.Drawing.Point(298, 113);
            this.textBoxKm.Name = "textBoxKm";
            this.textBoxKm.Size = new System.Drawing.Size(100, 20);
            this.textBoxKm.TabIndex = 2;
            this.textBoxKm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxKm_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(238, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "KM";
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(298, 81);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(100, 20);
            this.textBoxPrice.TabIndex = 2;
            this.textBoxPrice.TextChanged += new System.EventHandler(this.textBoxPrice_TextChanged);
            this.textBoxPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPrice_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(238, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Price";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(298, 51);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(200, 20);
            this.textBoxName.TabIndex = 2;
            this.textBoxName.TextChanged += new System.EventHandler(this.textBoxName_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(238, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(141, 6);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.buttonDellete);
            this.tabPage2.Controls.Add(this.total);
            this.tabPage2.Controls.Add(this.otherTotal);
            this.tabPage2.Controls.Add(this.bodyTotal);
            this.tabPage2.Controls.Add(this.serviceTotal);
            this.tabPage2.Controls.Add(this.transmitionTotal);
            this.tabPage2.Controls.Add(this.suspensionTotal);
            this.tabPage2.Controls.Add(this.engineTotal);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(547, 218);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Data";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // buttonDellete
            // 
            this.buttonDellete.Location = new System.Drawing.Point(-4, 0);
            this.buttonDellete.Name = "buttonDellete";
            this.buttonDellete.Size = new System.Drawing.Size(49, 23);
            this.buttonDellete.TabIndex = 3;
            this.buttonDellete.Text = "Dellete";
            this.buttonDellete.UseVisualStyleBackColor = true;
            this.buttonDellete.Click += new System.EventHandler(this.buttonDellete_Click);
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total.Location = new System.Drawing.Point(467, 181);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(32, 24);
            this.total.TabIndex = 2;
            this.total.Text = "0$";
            this.total.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // otherTotal
            // 
            this.otherTotal.AutoSize = true;
            this.otherTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.otherTotal.Location = new System.Drawing.Point(382, 192);
            this.otherTotal.Name = "otherTotal";
            this.otherTotal.Size = new System.Drawing.Size(21, 13);
            this.otherTotal.TabIndex = 2;
            this.otherTotal.Text = "0$";
            this.otherTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bodyTotal
            // 
            this.bodyTotal.AutoSize = true;
            this.bodyTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bodyTotal.Location = new System.Drawing.Point(320, 192);
            this.bodyTotal.Name = "bodyTotal";
            this.bodyTotal.Size = new System.Drawing.Size(21, 13);
            this.bodyTotal.TabIndex = 2;
            this.bodyTotal.Text = "0$";
            this.bodyTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // serviceTotal
            // 
            this.serviceTotal.AutoSize = true;
            this.serviceTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceTotal.Location = new System.Drawing.Point(257, 192);
            this.serviceTotal.Name = "serviceTotal";
            this.serviceTotal.Size = new System.Drawing.Size(21, 13);
            this.serviceTotal.TabIndex = 2;
            this.serviceTotal.Text = "0$";
            this.serviceTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // transmitionTotal
            // 
            this.transmitionTotal.AutoSize = true;
            this.transmitionTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transmitionTotal.Location = new System.Drawing.Point(184, 192);
            this.transmitionTotal.Name = "transmitionTotal";
            this.transmitionTotal.Size = new System.Drawing.Size(21, 13);
            this.transmitionTotal.TabIndex = 2;
            this.transmitionTotal.Text = "0$";
            this.transmitionTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // suspensionTotal
            // 
            this.suspensionTotal.AutoSize = true;
            this.suspensionTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.suspensionTotal.Location = new System.Drawing.Point(103, 192);
            this.suspensionTotal.Name = "suspensionTotal";
            this.suspensionTotal.Size = new System.Drawing.Size(21, 13);
            this.suspensionTotal.TabIndex = 2;
            this.suspensionTotal.Text = "0$";
            this.suspensionTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // engineTotal
            // 
            this.engineTotal.AutoSize = true;
            this.engineTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.engineTotal.Location = new System.Drawing.Point(35, 192);
            this.engineTotal.Name = "engineTotal";
            this.engineTotal.Size = new System.Drawing.Size(21, 13);
            this.engineTotal.TabIndex = 2;
            this.engineTotal.Text = "0$";
            this.engineTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(453, 154);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 24);
            this.label10.TabIndex = 1;
            this.label10.Text = " Total:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(312, 154);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 26);
            this.label9.TabIndex = 1;
            this.label9.Text = "Body kit \r\n total:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(373, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 26);
            this.label8.TabIndex = 1;
            this.label8.Text = "Other\r\n total:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(251, 154);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 26);
            this.label7.TabIndex = 1;
            this.label7.Text = "Sevice \r\n total:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(166, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 26);
            this.label6.TabIndex = 1;
            this.label6.Text = "Transmition \r\n total:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(86, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 26);
            this.label5.TabIndex = 1;
            this.label5.Text = "Suspension \r\n total:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 26);
            this.label4.TabIndex = 1;
            this.label4.Text = "Engine \r\n total:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.type,
            this.name,
            this.price,
            this.km,
            this.date});
            this.dataGridView1.Location = new System.Drawing.Point(3, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(549, 151);
            this.dataGridView1.TabIndex = 0;
            // 
            // type
            // 
            this.type.HeaderText = "Type";
            this.type.Name = "type";
            this.type.ReadOnly = true;
            // 
            // name
            // 
            this.name.HeaderText = "Name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // price
            // 
            this.price.HeaderText = "Price";
            this.price.Name = "price";
            this.price.ReadOnly = true;
            this.price.Width = 80;
            // 
            // km
            // 
            this.km.HeaderText = "KM";
            this.km.Name = "km";
            this.km.ReadOnly = true;
            this.km.Width = 80;
            // 
            // date
            // 
            this.date.HeaderText = "Date";
            this.date.Name = "date";
            this.date.ReadOnly = true;
            this.date.Width = 140;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 236);
            this.Controls.Add(this.tabControl1);
            this.MaximumSize = new System.Drawing.Size(567, 275);
            this.MinimumSize = new System.Drawing.Size(567, 275);
            this.Name = "Form1";
            this.Text = "Car parts price tracker";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBoxType.ResumeLayout(false);
            this.groupBoxType.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.GroupBox groupBoxType;
        private System.Windows.Forms.RadioButton radioButtonOther;
        private System.Windows.Forms.RadioButton radioButtonBody;
        private System.Windows.Forms.RadioButton radioButtonService;
        private System.Windows.Forms.RadioButton radioButtonTransmition;
        private System.Windows.Forms.RadioButton radioButtonEngine;
        private System.Windows.Forms.RadioButton radioButtonSuspension;
        private System.Windows.Forms.TextBox textBoxKm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Label otherTotal;
        private System.Windows.Forms.Label bodyTotal;
        private System.Windows.Forms.Label serviceTotal;
        private System.Windows.Forms.Label transmitionTotal;
        private System.Windows.Forms.Label suspensionTotal;
        private System.Windows.Forms.Label engineTotal;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonDellete;
        private System.Windows.Forms.DataGridViewTextBoxColumn type;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewTextBoxColumn km;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
    }
}

